<?php
use phpGrid\C_DataGrid;
require_once("../phpGrid/conf.php");      
include_once('../inc/head.php');
?>

<h1>My Custom CRM</h1>

<?php
include_once('../inc/menu.php');
?>

<h3>Section Title</h2>
<?php
// ..phpGrid code goes here
?>

<?php
include_once('../inc/footer.php');
?>