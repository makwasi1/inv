<br /><br /><br /><br /><br />
<div class="footer"><strong>Build-From-Scratch Series</strong> | phpGrid &copy; <?php echo date('Y'); ?>.</div>

</body>
</html>